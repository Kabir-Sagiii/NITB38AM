import React from "react";

function PageNF(props) {
  return (
    <div>
      <p className="display-4 text-center text-danger">Page not found</p>
    </div>
  );
}

export default PageNF;
